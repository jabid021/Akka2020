import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

import config.Context;
import model.Conge;
import model.Manager;
import model.Salarie;
import model.Service;
import model.TypeConge;

public class test {

	public static void main(String[] args) {

//		Service service1 = new Service("Compta");
//		service1 = Context.getInstance().getDaoService().save(service1);
//		Service service2 = new Service("Secretaire");
//		service2 = Context.getInstance().getDaoService().save(service2);
//		Service service3 = new Service("Developpeur");
//		service3 = Context.getInstance().getDaoService().save(service3);
//		
//		Manager manager = new Manager("manager@mail", "pass", "Abid", "Jordan", service1);
//		Context.getInstance().getDaoManager().save(manager);
//		
//		Salarie salarie1 = new Salarie("vanessa@mail", "pass", "Desmartin", "Vanessa", service1);
//		Salarie salarie2 = new Salarie("Eli@mail", "pass", "Dupont", "Elisabeth", service2);
//		Salarie salarie3 = new Salarie("kelly@mail", "pass", "Daniel", "Kelly", service3);
//		salarie1 = Context.getInstance().getDaoSalarie().save(salarie1);
//		salarie2 = Context.getInstance().getDaoSalarie().save(salarie2);
//		salarie3 = Context.getInstance().getDaoSalarie().save(salarie3);
//
//		Conge conge0 = new Conge(salarie1, TypeConge.CP, LocalDate.of(2021, 01, 18), LocalDate.of(2021, 01, 20), "Vacances aux caraibes");
//		Conge conge1 = new Conge(salarie1, TypeConge.CJ, LocalDate.of(2021, 02, 18), LocalDate.of(2021, 02, 20), "Vacances en Australie");
//		Conge conge2 = new Conge(salarie1, TypeConge.CSS, LocalDate.of(2021, 03, 18), LocalDate.of(2021, 03, 20), "Vacances en Egypte");
//		Conge conge3 = new Conge(salarie2, TypeConge.CP, LocalDate.of(2021, 01, 18), LocalDate.of(2021, 01, 20), "Vacances aux Etats-Unis");
//		Conge conge4 = new Conge(salarie2, TypeConge.CA, LocalDate.of(2021, 02, 18), LocalDate.of(2021, 02, 20), "Vacances en Finlande");
//		Conge conge5 = new Conge(salarie3, TypeConge.CP, LocalDate.of(2021, 01, 13), LocalDate.of(2021, 02, 15), "Vacances en Espagnes");
//		Conge conge6 = new Conge(salarie3, TypeConge.CP, LocalDate.of(2021, 02, 18), LocalDate.of(2021, 02, 20), "Vacances au Portugal");
//
//		Context.getInstance().getDaoConge().save(conge0);
//		Context.getInstance().getDaoConge().save(conge1);
//		Context.getInstance().getDaoConge().save(conge2);
//		Context.getInstance().getDaoConge().save(conge3);
//		Context.getInstance().getDaoConge().save(conge4);
//		Context.getInstance().getDaoConge().save(conge5);
//		Context.getInstance().getDaoConge().save(conge6);
	}

}
