package dao;

import model.Manager;

public interface IDAOManager extends IDAO<Manager,Integer>{

		
}
